function output=logarithm(input)
value=1;
while value<input
    value=value*2;
end
output=1;
end