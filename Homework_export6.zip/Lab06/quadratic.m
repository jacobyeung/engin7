function output=quadratic(input)
for i = 1:input
    for j=1:input
        output=j+i;
    end
end
end