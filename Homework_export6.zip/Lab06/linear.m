function output=linear(input)
for i = 1:input
    output=i;
end
end