function output=cubic(input)
for i = 1:input
    for j=1:input
        for k = 1:input
            output=i+j+k;
        end
    end
end
end