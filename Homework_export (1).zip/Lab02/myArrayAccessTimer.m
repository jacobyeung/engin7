function [time1, time2, time3] = myArrayAccessTimer(matrix)

    tic;
    x = 
    time1 = 

    tic;
    y = 
    time2 = 

    tic;
    
    z = 
    time3 = 
end