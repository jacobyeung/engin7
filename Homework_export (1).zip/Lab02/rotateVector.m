function [u_rotated] = rotateVector(u,angle)
rotation=
u_rotated=
end