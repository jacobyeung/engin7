function [answers] = myBigOAnswers()
answers = ['a' 'd' 'a' 'e'];