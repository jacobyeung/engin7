classdef minHeap < handle
    properties (Access = public)
        % Define the public properties
    end
    properties (Access = private)
        % Define the private properties
    end
    
    methods 
        function createHeap(obj,nodes)
            % Implement the required code as described in the assignment
        end
        
        function nodes = checkSize(obj)
            % Implement the required code as described in the assignment
        end
        
        function push(obj,value)
            % Implement the required code as described in the assignment
        end
        
        function value = pop(obj)
           % Implement the required code as described in the assignment
        end
    end
end