function [grade] = searchGrade(name,scores_lab04)
if nargin < 2
    load('scores_lab04.mat','scores_lab04');
end
%-------Don't change above code--------%
end

