function [sigma2, abs_sigma2] = myVar(x1, x2, x3)
[ave, abs_ave] = myMean( )
sigma2 = 
abs_sigma2 = 
end

