function [ave, abs_ave] = myMean(x1, x2, x3)
ave = 
abs_ave = 
end
