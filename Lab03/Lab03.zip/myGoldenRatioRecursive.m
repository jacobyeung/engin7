function ratio2 = myGoldenRatioRecursive(m)
ratio2 = myFArray(m + 1) / myFArray(m);
end

