classdef wordList < handle
    properties (SetAccess = protected)
        % Fill in the accessable properties
    end
    properties (Access = private) % Do not change this line
        % Fill in the restricted properties
    end
    
    methods        
        function uniqueWords = getUnique(obj)
           % fill in function for getUnique 
        end
        
        function totalWords = getTotal(obj)
           % fill in function for getTotal
        end
        
        function add(obj, newWord)
            assert(isa(newWord, 'myWordNode'));
            if obj.totalWords == 0
                newWord.prev = myWordNode.empty;
                newWord.next = myWordNode.empty;
                obj.head = newWord;
                obj.tail = newWord;
                obj.uniqueWords = 1;
                obj.totalWords = 1;
            else
                current = obj.head;
                alphabet = sort({newWord.word,current.word});
                if strcmp(current.word,newWord.word)
                    current.occurrences = current.occurrences + 1;
                    obj.totalWords = obj.totalWords + 1;
                    return
                elseif strcmp(alphabet{1},newWord.word) 
                    obj.head = newWord;
                    obj.head.next = current;
                    current.prev = obj.head;
                    obj.uniqueWords = obj.uniqueWords + 1;
                    obj.totalWords = obj.totalWords + 1;
                    return
                end
                while strcmp(alphabet{2},newWord.word) 
                    if isempty(current.next)
                        if strcmp(current.word,newWord.word)
                            current.occurrences = current.occurrences + 1;
                            obj.totalWords = obj.totalWords + 1;
                        else
                            current.next = newWord;
                            newWord.prev = current;
                            obj.uniqueWords = obj.uniqueWords + 1;
                            obj.totalWords = obj.totalWords + 1;
                            obj.tail = newWord;
                        end
                        return
                    else
                        if strcmp(current.word,newWord.word)
                            current.occurrences = current.occurrences + 1;
                            obj.totalWords = obj.totalWords + 1;
                            return
                        else
                            current = current.next;
                            alphabet = sort({newWord.word,current.word});
                        end
                    end
                end
                current = current.prev;
                newWord.prev = current;
                newWord.next = current.next;
                current.next = newWord;
                newWord.next.prev = newWord;
                obj.uniqueWords = obj.uniqueWords + 1;
                obj.totalWords = obj.totalWords + 1;
            end
        end
        
        function removedNode = removeWord(obj,word)
            % fill in function for removeWord
        end
        
        function node = retrieveWord(obj, word)
            % fill in function for retrieveWord
        end
        
        function wordBank = printList(obj)
            % fill in function for printList
        end
               
        function frequency = wordFrequency(obj,word)
            % fill in function for wordFrequency - don't forget nargin
        end
        
        function relativeFreq = relativeFreq(obj,word)
            % fill in function for relativeFreq - don't forget nargin
        end
    end
end